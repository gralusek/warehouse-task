package com.example.ttpsc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TtpscApplicationTests {

    @Test
    void contextLoads() {
    }

}
