package com.example.ttpsc.domain;

public enum CargoCat {
    INDUSTRIAL, RAWMATERIAL, MERCHANDISE, OTHER;
}
